<?php
/**
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace ZendDiagnostics\Result;

class Failure extends AbstractResult implements FailureInterface
{
}
