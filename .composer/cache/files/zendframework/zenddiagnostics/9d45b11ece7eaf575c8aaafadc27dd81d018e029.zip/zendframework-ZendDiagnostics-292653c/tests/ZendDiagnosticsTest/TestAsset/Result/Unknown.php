<?php
namespace ZendDiagnosticsTest\TestAsset\Result;

use \ZendDiagnostics\Result\AbstractResult;

class Unknown extends AbstractResult
{
}
