#!/usr/bin/env sh
set -ev

pip install -r docs/requirements.txt --user $(whoami)
