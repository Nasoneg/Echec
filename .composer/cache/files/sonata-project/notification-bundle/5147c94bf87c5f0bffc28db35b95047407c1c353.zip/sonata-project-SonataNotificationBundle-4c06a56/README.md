Sonata Notification Bundle
==========================

[![Build Status](https://secure.travis-ci.org/sonata-project/SonataNotificationBundle.png)](https://secure.travis-ci.org/#!/sonata-project/SonataNotificationBundle)

This bundle provides a notification mechanism through abstracted message queues.

Check out the documentation on [https://sonata-project.org/bundles/notification/master/doc/index.html](https://sonata-project.org/bundles/notification/master/doc/index.html)

**Google Groups**: For questions and proposals you can post on this google groups

* [Sonata Users](https://groups.google.com/group/sonata-users): Only for user questions
* [Sonata Devs](https://groups.google.com/group/sonata-devs): Only for devs

License
-------

This bundle is available under the [MIT license](Resources/meta/LICENSE).
