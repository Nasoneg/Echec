CHANGELOG
=========

### 2013-07-13

* [BC BREAK] We have introduced the `ChannelField` to add custom fields to your feed's main channel
   so we have moved the `\Eko\FeedBundle\Item\Field` class to `\Eko\FeedBundle\Field\ItemField`.