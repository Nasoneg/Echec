CHANGELOG
=========

### 2012-05-02

* [BC BREAK] add ProxyQueryInterface hint into the FilterInterface class
