<?php

$container->loadFromExtension('framework', array(
    'csrf_protection' => array(
        'enabled' => false,
    ),
));
