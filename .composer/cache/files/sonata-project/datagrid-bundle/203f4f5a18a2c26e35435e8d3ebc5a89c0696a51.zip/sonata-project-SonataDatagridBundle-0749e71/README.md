SonataDatagridBundle
====================

[![Build Status](https://secure.travis-ci.org/sonata-project/SonataDatagridBundle.png?branch=master)](http://travis-ci.org/sonata-project/SonataDatagridBundle)

This bundle provides base class to generate Datagrid.

The online documentation of the bundle is in https://sonata-project.org/bundles/datagrid

For contribution to the documentation you cand find it on [Resources/doc](https://github.com/sonata-project/SonataDatagridBundle/tree/master/Resources/doc).

**Warning**: documentation files are not rendering correctly in Github (reStructuredText format)
and some content might be broken or hidden, make sure to read raw files.

**Google Groups**: For questions and proposals you can post on these google groups

* [Sonata Users](https://groups.google.com/group/sonata-users): For questions on how to use Sonata bundles on your project
* [Sonata Devs](https://groups.google.com/group/sonata-devs): For questions regarding the development of Sonata bundles

License
-------

This bundle is available under the [MIT license](Resources/meta/LICENSE).
