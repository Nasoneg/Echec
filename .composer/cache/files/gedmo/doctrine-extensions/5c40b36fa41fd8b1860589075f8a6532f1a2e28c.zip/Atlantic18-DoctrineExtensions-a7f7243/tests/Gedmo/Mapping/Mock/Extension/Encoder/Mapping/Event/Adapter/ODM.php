<?php

namespace Gedmo\Mapping\Mock\Extension\Encoder\Mapping\Event\Adapter;

use Gedmo\Mapping\Event\Adapter\ODM as BaseAdapterODM;

final class ODM extends BaseAdapterODM
{
}
