<?php

namespace Test\Tool;

use PHPUnit_Framework_TestCase;

/**
 * Base test case
 */
abstract class BaseTestCase extends PHPUnit_Framework_TestCase
{
    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {

    }
}