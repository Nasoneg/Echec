#!/usr/bin/env sh
set -ev

coveralls -v
