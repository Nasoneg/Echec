<?php
/**
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace ZendDiagnostics\Result;

class Success extends AbstractResult implements SuccessInterface
{
}
