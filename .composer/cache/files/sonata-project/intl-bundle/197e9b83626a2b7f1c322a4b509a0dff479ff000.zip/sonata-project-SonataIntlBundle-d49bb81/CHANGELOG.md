CHANGELOG
=========

A [BC BREAK] means the update will break the project for many reasons :

* new mandatory configuration
* new dependencies
* class refactoring

### 2012-03-18
* Added a new way of determining the right timezone for the datetime output. You can now configure your own service for the timezone detection or use the naive approach provided by the bundle.

### 2011-02-19
* initial commit
