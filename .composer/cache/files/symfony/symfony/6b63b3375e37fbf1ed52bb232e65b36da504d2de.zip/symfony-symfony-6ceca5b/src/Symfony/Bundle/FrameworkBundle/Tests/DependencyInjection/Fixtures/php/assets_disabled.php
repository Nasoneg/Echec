<?php

$container->loadFromExtension('framework', array(
    'templating' => array(
        'engines' => array('php', 'twig'),
    ),
));
