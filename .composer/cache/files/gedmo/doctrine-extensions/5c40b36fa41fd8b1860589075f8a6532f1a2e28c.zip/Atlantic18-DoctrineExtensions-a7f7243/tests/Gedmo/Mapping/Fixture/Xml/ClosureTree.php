<?php

namespace Mapping\Fixture\Xml;

class ClosureTree
{
    private $id;

    private $name;

    private $parent;

    private $level;
}
