Introduction
============

The notification bundle allows to generate messages which can be retrieved by a generic backend and processed by
specific actions. This bundle does not try to reproduce a real message queue system as this bundle
can be used with a message queue system.

