<?php
/**
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace ZendDiagnostics\Result;

class Skip extends AbstractResult implements SkipInterface
{
}
