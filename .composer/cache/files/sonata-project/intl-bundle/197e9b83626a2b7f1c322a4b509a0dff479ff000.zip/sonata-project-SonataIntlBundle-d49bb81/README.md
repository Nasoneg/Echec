Sonata Intl Bundle
==================

[![Build Status](https://api.travis-ci.org/sonata-project/SonataIntlBundle.png)](https://travis-ci.org/sonata-project/SonataIntlBundle)

The ``SonataIntlBundle`` provides text and date formatting depends on locale.

Check out the documentation on [https://sonata-project.org/bundles/intl/master/doc/index.html](https://sonata-project.org/bundles/intl/master/doc/index.html)

**Google Groups**: For questions and proposals you can post on this google groups

* [Sonata Users](https://groups.google.com/group/sonata-users): Only for user questions
* [Sonata Devs](https://groups.google.com/group/sonata-devs): Only for devs

License
-------

This bundle is available under the [MIT License](Resources/meta/LICENSE).
