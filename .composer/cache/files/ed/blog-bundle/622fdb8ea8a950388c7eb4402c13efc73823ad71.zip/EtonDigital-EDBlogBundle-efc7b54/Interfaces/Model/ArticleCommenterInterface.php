<?php
/**
 * Created by Eton Digital.
 * User: Vladimir Mladenovic (vladimir.mladenovic@etondigital.com)
 * Date: 10.6.15.
 * Time: 14.23
 */

namespace ED\BlogBundle\Interfaces\Model;


interface ArticleCommenterInterface
{
    public function getCommenterDisplayName();
}