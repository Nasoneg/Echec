<?php

namespace Gedmo\Mapping\Mock\Mapping\Event\Adapter;

use Gedmo\Mapping\Event\Adapter\ORM as EventAdapterORM;

class ORM extends EventAdapterORM
{
}
