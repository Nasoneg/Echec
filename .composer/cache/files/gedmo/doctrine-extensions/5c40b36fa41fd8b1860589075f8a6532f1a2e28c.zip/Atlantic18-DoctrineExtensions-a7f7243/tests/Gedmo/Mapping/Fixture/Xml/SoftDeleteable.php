<?php

namespace Mapping\Fixture\Xml;

class SoftDeleteable
{
    private $id;

    private $deletedAt;
}
