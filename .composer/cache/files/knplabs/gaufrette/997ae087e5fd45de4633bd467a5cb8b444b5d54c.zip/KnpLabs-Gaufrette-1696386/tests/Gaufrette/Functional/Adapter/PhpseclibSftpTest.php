<?php

namespace Gaufrette\Functional\Adapter;

use Gaufrette\Adapter\PhpseclibSftp;

class PhpseclibSftpTest extends FunctionalTestCase
{
}
