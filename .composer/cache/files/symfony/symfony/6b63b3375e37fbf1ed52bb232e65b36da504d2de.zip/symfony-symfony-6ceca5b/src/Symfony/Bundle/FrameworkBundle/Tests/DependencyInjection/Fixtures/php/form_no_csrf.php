<?php

$container->loadFromExtension('framework', array(
    'form' => array(
        'enabled' => true,
        'csrf_protection' => false,
    ),
));
