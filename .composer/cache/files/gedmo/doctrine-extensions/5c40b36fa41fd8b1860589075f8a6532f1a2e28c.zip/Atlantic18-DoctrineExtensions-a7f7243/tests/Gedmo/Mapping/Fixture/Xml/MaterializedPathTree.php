<?php

namespace Mapping\Fixture\Xml;

class MaterializedPathTree
{
    private $id;

    private $title;

    private $path;

    private $lockTime;

    private $parent;

    private $level;
}
